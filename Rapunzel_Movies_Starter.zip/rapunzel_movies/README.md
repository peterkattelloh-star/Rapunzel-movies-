# Rapunzel Movies — starter app

A mobile-friendly movie-library web app with a dark blue and purple theme.

## Run it
Open `index.html` in a browser for a basic preview. For installable PWA/offline app-shell support, host the folder on HTTPS (for example GitHub Pages).

## Included
- Responsive home page and movie library
- Search, genre filter and sorting
- Add movie/series entries
- Watchlist saved in browser local storage
- HTML5 video playback for a user-provided authorised video URL
- Download link for a user-provided authorised download URL
- PWA manifest and service worker for caching the app shell

## Important limitations
This is the first frontend prototype. It does not include a server, user accounts, cloud database, payment system, or a catalogue of hosted films. Movie entries are stored only in the browser/device where they are added. Add only movie files and streams you own or are licensed/authorised to distribute. Playback/download depends on the host's permissions, CORS settings, and browser support.
